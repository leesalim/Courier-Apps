<?php $__env->startSection('content'); ?>
<div class="col-lg-6">
    <div class="panel panel-default">
        <div class="panel-heading"><h4>LATEST DELIVERY REQUESTS</h4></div>

        <div class="panel-body">
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                        <h4><a href="/transactions/detail/<?php echo e($request->bookingid); ?>"><?php echo e($request->destcity); ?> - <?php echo e($request->pickupcity); ?></a></h4>
                        <div id="colorstar" class="starrr ratable">
                            <span class="glyphicon <?php if($request->userrating >= 1): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                            <span class="glyphicon <?php if($request->userrating >= 2): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                            <span class="glyphicon <?php if($request->userrating >= 3): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                            <span class="glyphicon <?php if($request->userrating >= 4): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                            <span class="glyphicon <?php if($request->userrating >= 5): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                        </div>

                        <small>Posted by: <a href="#"><?php echo e($request->firstname . ' ' . $request->lastname); ?></a> on <?php echo e($request->dateadded); ?></small>
                    </div>

                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before <?php echo e($request->targetdeldatetime); ?></i>
                        <h2>P <?php echo e(number_format($request->deliverycharge, 2, '.', ',')); ?></h2>
                        <small>Same Day - Meet Up</small>
                    </div>

                    <div class="fb-like" data-href="https://developers.facebook.com/docs/plugins/request<?php echo e($request->bookingid); ?>" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<div class="col-lg-6">
    <div class="panel panel-default">
        <div class="panel-heading"><h4>LATEST DELIVERY OFFERS</h4></div>

        <div class="panel-body">
           <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                        <h4><a href="/transactions/detail/<?php echo e($offer->bookingid); ?>"><?php echo e($offer->destcity); ?> - <?php echo e($offer->pickupcity); ?></a></h4>
                        <div id="colorstar" class="starrr ratable">
                            <span class="glyphicon <?php if($offer->userrating >= 1): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                            <span class="glyphicon <?php if($offer->userrating >= 2): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                            <span class="glyphicon <?php if($offer->userrating >= 3): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                            <span class="glyphicon <?php if($offer->userrating >= 4): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                            <span class="glyphicon <?php if($offer->userrating >= 5): ?> glyphicon-star <?php else: ?> glyphicon-star-empty <?php endif; ?>"></span>
                        </div>

                        <small>Posted by: <a href="#"><?php echo e($offer->firstname . ' ' . $offer->lastname); ?></a> on <?php echo e($offer->dateadded); ?></small>
                    </div>

                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before <?php echo e($offer->targetdeldatetime); ?></i>
                        <h2>P <?php echo e(number_format($offer->deliverycharge, 2, '.', ',')); ?></h2>
                        <small></small>
                    </div>


                </div>

                 <div class="fb-like" data-href="https://developers.facebook.com/docs/plugins/offer<?php echo e($offer->bookingid); ?>" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>