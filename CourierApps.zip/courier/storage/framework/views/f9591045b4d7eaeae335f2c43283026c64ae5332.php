<?php $__env->startSection('content'); ?>
<div class="container">
    <form enctype="multipart/form-data" action="<?php echo e(route('profile')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >

        <div class="row">
            <h3>Profile Information</h3><br/>
            <div class="col-md-3 col-lg-3 " align="center">
                <div>
                    <?php if(!$user->avatarlink): ?>
                    <img src="/uploads/avatars/default.jpg" style="width: 150px; height: 150px; float:left; border-radius: 50%; margin-right: 25px">
                    <?php else: ?>
                    <img src="/uploads/avatars/<?php echo e($user->avatarlink); ?>" style="width: 150px; height: 150px; float:left; border-radius: 50%; margin-right: 25px">
                    <?php endif; ?>
                </div>

                <div>
                    <input type="file" name="avatarlink">
                </div>
            </div>

            <div class="col-md-6 col-lg-6">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <select class="form-control" tabindex="6" id="accounttype" name="accounttype">
                              <option disabled selected>Account Type</option>

                              <?php if( $user->accounttype == 'PERSONAL'): ?>
                              <option value="PERSONAL" selected>PERSONAL</option>
                              <?php else: ?>
                              <option value="PERSONAL">PERSONAL</option>
                              <?php endif; ?>

                              <?php if( $user->accounttype == 'COMPANY'): ?>
                              <option value="COMPANY" selected>COMPANY</option>
                              <?php else: ?>
                              <option value="COMPANY">COMPANY</option>
                              <?php endif; ?>
                          </select>
                          <small class="alert-danger"><?php echo e($errors->first('accounttype')); ?></small>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <select class="form-control" tabindex="6" id="defaultpayment" name="defaultpayment">
                              <option disabled selected>Payment Mode</option>

                              <?php if( $user->defaultpayment == 'CASH'): ?>
                              <option value="CASH" selected>CASH</option>
                              <?php else: ?>
                              <option value="CASH">CASH</option>
                              <?php endif; ?>

                              <?php if( $user->defaultpayment == 'CARD'): ?>
                              <option value="CARD" selected>CARD</option>
                              <?php else: ?>
                              <option value="CARD">CARD</option>
                              <?php endif; ?>
                          </select>
                          <small class="alert-danger"><?php echo e($errors->first('defaultpayment')); ?></small>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <input maxlength="100" type="text" class="form-control" value="<?php echo e($user->firstname); ?>" name="firstname" id="firstname" placeholder="First Name" autofocus="true" tabindex="1">
                            <small class="alert-danger"><?php echo e($errors->first('firstname')); ?></small>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control" tabindex="2" value="<?php echo e($user->lastname); ?>" name="lastname" id="lastname" placeholder="Last Name">
                            <small class="alert-danger"><?php echo e($errors->first('lastname')); ?></small>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <input maxlength="100" type="text" tabindex="3" class="form-control" value="<?php echo e($user->companyname); ?>" name="companyname" id="companyname" placeholder="Company Name">
                    <small class="alert-danger"><?php echo e($errors->first('companyname')); ?></small>
                </div>

                <div class="form-group">
                    <input maxlength="255" type="text" tabindex="4" class="form-control" value="<?php echo e($user->defaultaddress); ?>" name="defaultaddress" id="defaultaddress" placeholder="Address">
                    <small class="alert-danger"><?php echo e($errors->first('defaultaddress')); ?></small>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <input maxlength="20" type="text" tabindex="5" placeholder="Mobile No" class="form-control" value="<?php echo e($user->mobileno); ?>" name="mobileno" id="mobileno" >
                            <small class="alert-danger"><?php echo e($errors->first('mobileno')); ?></small>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <select class="form-control" tabindex="6" id="currencyid" name="currencyid">
                              <option disabled selected>Currency</option>
                              <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if( $user->currencyid == $currency->currencyid ): ?>
                                    <option value="<?php echo e($currency->currencyid); ?>" selected><?php echo e($currency->currencydesc); ?></option>
                                  <?php else: ?>
                                    <option value="<?php echo e($currency->currencyid); ?>"><?php echo e($currency->currencydesc); ?></option>
                                  <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <small class="alert-danger"><?php echo e($errors->first('currencyid')); ?></small>
                      </div>
                  </div>
                </div>
            </div>

            <div class="col-md-3 col-lg-4">

            </div>
        </div>

        <div class="row">
            <div class="col-md-12 col-lg-12">
                <h3>Supporting Documents</h3>
                <table class="table table-striped custab">
                  <tbody>
                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($document->documentdesc); ?></td>
                      <td><a href="#"><?php echo e($document->filename); ?></a></td>
                      <td><input type="file" name="<?php echo e($document->documentid); ?>" /></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </div>
        </div>

        <br/>
        <br/>


        <div class="row">
            <div class="col-md-12 col-lg-12">
                <input type="submit" class="btn btn-primary" value="Update">
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>