<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="panel panel-default">
    <div class="panel-heading"><h4>YOUR REQUESTS <a href="/transactions/requests/create" class="btn btn-xs btn-primary pull-right">Create New</a></h4></div>

        <div class="panel-body">
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                       <h4><a href="/transactions/detail/<?php echo e($request->bookingid); ?>"><?php echo e(ucwords($request->destcity)); ?> - <?php echo e(ucwords($request->pickupcity)); ?></a></h4>


                        <small>Posted by: <a href="#"><?php echo e($request->portalusername); ?></a> on <?php echo e($request->dateadded); ?></small>
                    </div>

                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before <?php echo e($request->targetdeldatetime); ?></i>
                        <h2>P <?php echo e(number_format($request->deliverycharge, 2, '.', ',')); ?></h2>
                        <small><?php echo e($request->pickupdatetime); ?></small>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>