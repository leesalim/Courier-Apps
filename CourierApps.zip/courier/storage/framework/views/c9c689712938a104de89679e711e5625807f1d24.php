<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="panel panel-default">
    <div class="panel-heading"><h4>YOUR REQUESTS <a href="/requests/create" class="btn btn-xs btn-primary pull-right">Create New</a></h4></div>

        <div class="panel-body">
            <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                        <h4>Makati to Navaliches</h4>
                        <div id="colorstar" class="starrr ratable"><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span></div>

                        <small>Posted by: <a href="#">Emman</a> on May 15, 2017 14:00:34</small>
                    </div>
                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before May 16, 2017 5:00 PM</i>
                        <h2>P 100.00</h2>
                        <small>Same Day - Meet Up</small>
                    </div>
                </div>
            </div>

            <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                        <h4>Marikina to Manila</h4>
                        <div id="colorstar" class="starrr ratable"><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span></div>

                        <small>Posted by: <a href="#">Emman</a> on May 15, 2017 14:00:34</small>
                    </div>
                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before May 16, 2017 5:00 PM</i>
                        <h2>Free to Offer</h2>
                        <small>Same Day - Meet Up</small>
                    </div>
                </div>
            </div>

            <div style="text-align: center;"><h3><a href="#">View More</a></h3></div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>