<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Courier Apps')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <style>
        div#app { overflow: hidden; }
    </style>
</head>
<body>
    <div id="fb-root"></div>

    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        Courier Apps
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" style="position: relative; padding-left: 50px">
                                <?php if(Auth::user()->avatarlink): ?>
                                <img src="/uploads/avatars/<?php echo e(Auth::user()->avatarlink); ?>"
                                style="width:32px; height:32px position: absolute; top: 10px; left: 10px; border-radius: 50%">
                                <?php else: ?>
                                <img src="/uploads/avatars/default.jpg"
                                style="width:32px; height:32px position: absolute; top: 10px; left: 10px; border-radius: 50%">
                                <?php endif; ?>
                                <?php echo e(Auth::user()->firstname . ' ' . Auth::user()->lastname); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu">
                                <li>
                                    <a href="<?php echo e(route('profile')); ?>">
                                        Profile
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="get" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>



    <div class="row">
        <aside class="col-sm-3 ml-sm-auto col-lg-2 blog-sidebar">
            <div class="sidebar-module sidebar-module-inset">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div><h3>My Account</h3></div>
                                <div class="search-item"><a href="/profile">Profile</a></div>
                            </div>

                            <div class="col-sm-12">
                                <div><h3>Transactions</h3></div>
                                <div class="search-item"><a href="/home">Home</a></div>
                                <div class="search-item"><a href="/transactions/requests">Requests</a></div>
                                <div class="search-item"><a href="/transactions/offers">Offers</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </aside>

        <content class="col-sm-6 ml-sm-auto col-lg-8 blog-sidebar">
            <?php echo $__env->yieldContent('content'); ?>
        </content>

        <aside class="col-sm-3 ml-sm-auto col-lg-2 blog-sidebar">
            <div class="sidebar-module sidebar-module-inset">
                <div class="panel panel-default" style="position: fixed; width: 100%; height: 100%;">
                    <div class="panel-body">
                        <?php $__currentLoopData = $onlineUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="online-user">
                            <span class="online-indicator">•</span>
                            <span class="name"><?php echo e($user->firstname . ' ' . $user->lastname); ?></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </aside>
    </div>
</div>

<!-- Scripts -->

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.11';
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

<script type="text/javascript">

</script>
</body>
</html>
