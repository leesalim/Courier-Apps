Hi <b><?php echo e($name); ?></b>,

<p>Click the link given below to complete your registration.</p>
<br/>
&nbsp;&nbsp;&nbsp; <a href="<?php echo e($link); ?>"><?php echo e($link); ?></a>