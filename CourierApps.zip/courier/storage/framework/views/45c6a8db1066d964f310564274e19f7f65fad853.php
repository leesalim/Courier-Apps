<!DOCTYPE html>
<html lang="en">
<title></title>
<head>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>


	<div class="container">
		<div class="row">
			<div class="col-lg-offset-3 col-lg-6">
				<form action="<?php echo e(route('custom.register')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

					<fieldset>
						<legend>Register Here!</legend>
						<div class="form-group">
							<label for="firstname">First Name </label>

							<input type="text" class="form-control" value="<?php echo e(old('firstname')); ?>" name="firstname" id="firstname">
							<small class="alert-danger"><?php echo e($errors->first('firstname')); ?></small>
						</div>
						<div class="form-group">
							<label for="lastname">Last Name</label>
							<input type="text" class="form-control" value="<?php echo e(old('lastname')); ?>" name="lastname" id="lastname">
							<small class="alert-danger"><?php echo e($errors->first('lastname')); ?></small>
						</div>
						<div class="form-group">
							<label for="emailaddress">Email Address</label>
							<input type="email" class="form-control" value="<?php echo e(old('emailaddress')); ?>" name="emailaddress" id="emailaddress" aria-describedby="emailHelp">
							<small class="alert-danger"><?php echo e($errors->first('emailaddress')); ?></small>
						</div>
						<div class="form-group">
							<label for="password">Password</label>
							<input type="password" class="form-control" name="password" id="password">
							<small class="alert-danger"><?php echo e($errors->first('password')); ?></small>
						</div>

						<div class="form-group">
							<label for="password_confirmation">Re-Password</label>
							<input type="password" class="form-control" name="password_confirmation" id="password_confirmation">
						</div>

						<div class="form-group">
							<?php echo Recaptcha::render(); ?>

							<small class="alert-danger"><?php echo e($errors->first('g-recaptcha-response')); ?></small>
						</div>


						<button type="submit" class="btn btn-primary btn-block">Register</button>
					</fieldset>
				</form>
			</div>
		</div>
	</div>

	<script
	src="http://code.jquery.com/jquery-3.2.1.js"
	integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
	crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html>