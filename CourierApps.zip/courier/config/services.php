<?php

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

$url = $protocol . $_SERVER['HTTP_HOST'];

return [

	/*
		    |--------------------------------------------------------------------------
		    | Third Party Services
		    |--------------------------------------------------------------------------
		    |
		    | This file is for storing the credentials for third party services such
		    | as Stripe, Mailgun, SparkPost and others. This file provides a sane
		    | default location for this type of information, allowing packages
		    | to have a conventional place to find your various credentials.
		    |
	*/

	'mailgun' => [
		'domain' => env('MAILGUN_DOMAIN'),
		'secret' => env('MAILGUN_SECRET'),
	],

	'ses' => [
		'key' => env('SES_KEY'),
		'secret' => env('SES_SECRET'),
		'region' => 'us-east-1',
	],

	'sparkpost' => [
		'secret' => env('SPARKPOST_SECRET'),
	],

	'stripe' => [
		'model' => App\User::class,
		'key' => env('STRIPE_KEY'),
		'secret' => env('STRIPE_SECRET'),
	],

	'facebook' => [
		'client_id' => '757344284439849',
		'client_secret' => 'de949ba889d9ec052df351d9420edbcf',
		'redirect' => $url . '/custom-login/socialite/facebook/callback',
	],

	'twitter' => [
		'client_id' => 'MPZvC2E97Yh8aExUTUb7MCjqu',
		'client_secret' => 'xMLIgXDXyw1EQwtPWGbQnC5pgR1HPGaRbVLkVQ4t2cKEPyt9kv',
		'redirect' => $url . '/custom-login/socialite/twitter/callback',
	],

	'google' => [
		'client_id' => '460595203129-gf43mpdh2sdecrljfc8pb9vea2atj92i.apps.googleusercontent.com',
		'client_secret' => '4VkCFYcMQ54v2yK3EeAmAcg2',
		'redirect' => $url . '/custom-login/socialite/google/callback',
	],

	'linkedin' => [
		'client_id' => '81n4ramexclyhp',
		'client_secret' => 'k0lwOQicvqo59zUD',
		'redirect' => $url . '/custom-login/socialite/linkedin/callback',
	],

];
