<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::get('/', function () {
	return view('welcome');
});

/**
 * Transactions
 *
 */
Route::get('/home', 'TransactionController@home')->name('home');

Route::get('transactions/{type}', 'TransactionController@index')->name('transactions');
Route::get('transactions/detail/{id}', 'TransactionController@detail')->name('transaction-detail');

Route::get('transactions/offers/create', 'TransactionController@createOffer')->name('request');
Route::post('transactions/offers/create', 'TransactionController@submitOffer')->name('request-submit');

Route::get('transactions/requests/create', 'TransactionController@createRequest')->name('offer');
Route::post('transactions/requests/create', 'TransactionController@submitRequest')->name('offer-submit');

/**
 * User
 *
 */
Route::get('profile', 'UserController@profile')->name('profile');
Route::post('profile', 'UserController@updateAvatar');
/**
 * Forgot Password
 *
 */
Route::get('forgot', function () {
	return view('forgot');
})->name('forgot');
Route::post('forgot', 'CustomAuthController@forgot');

/**
 * Reset Password
 *
 */
Route::get('reset/v/{versionId}/t/{tokenId}', 'CustomAuthController@showResetForm', function ($versionId, $tokenId) {
	return $versionId;
})->name('reset');
Route::post('reset/v/{versionId}/t/{tokenId}', 'CustomAuthController@reset')->name('resetpassword');

/**
 * User Registry
 *
 */
Route::get('user-register', 'CustomAuthController@showUserRegisterForm')->name('user-register');
Route::post('user-register', 'CustomAuthController@register');

Route::get('custom-register', 'CustomAuthController@showRegisterForm')->name('custom.register');
Route::post('custom-register', 'CustomAuthController@register');

/**
 * Authentication
 *
 */
Route::get('custom-login', 'CustomAuthController@showLoginForm')->name('custom.login');
Route::post('custom-login', 'CustomAuthController@login');

Route::get('logout', 'CustomAuthController@logout')->name('logout');

Route::get('verify/v/{v}/t/{token}', 'CustomAuthController@verify', function ($versionId, $tokenId) {
	return $versionId;
});

Auth::routes();

//Socialite
Route::get('custom-login/socialite/{socialite}', 'CustomAuthController@redirectToProvider', function ($socialite) {});
Route::get('custom-login/socialite/{socialite}/callback', 'CustomAuthController@handleProviderCallback', function ($socialite) {});
