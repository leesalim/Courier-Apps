<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Proposal extends Model {
	protected $table = 'opc_gm_bookingproposal';
	public $timestamps = false;

	protected $fillable = [
		'bookingid', 'portaluserid', 'deliverycharge', 'vehicletypeid', 'targetdeldatetime',
		'pickupdatetime', 'drivername', 'drivercontact', 'additionalnotes', 'isreturntopickup',
		'datecancelled',
	];
}
