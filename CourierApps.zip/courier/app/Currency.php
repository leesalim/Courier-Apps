<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model {
	protected $table = 'gm_gen_currency';
	protected $primaryKey = 'currencyid';

	protected $fillables = [
		'currencycode', 'currencydesc', 'currencyicon',
	];
}
