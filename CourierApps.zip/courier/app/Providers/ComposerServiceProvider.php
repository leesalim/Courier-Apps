<?php

namespace App\Providers;

use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\ServiceProvider;
use View;

class ComposerServiceProvider extends ServiceProvider {
	/**
	 * Bootstrap the application services.
	 *
	 * @return void
	 */
	public function boot() {
		View::composer('*', function ($view) {
			if (Auth::user()) {
				$users = DB::table('gm_gen_portaluser')
					->select('firstname', 'lastname', 'avatarlink')
					->where([
						['isonline', '=', 1],
						['emailaddress', '<>', Auth::user()->emailaddress],
					])
					->get();

				$view->with('onlineUsers', $users);
			}
		});
	}

	/**
	 * Register the application services.
	 *
	 * @return void
	 */
	public function register() {
		//
	}
}
