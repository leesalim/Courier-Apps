<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;

class User extends Authenticatable {

	protected $table = 'gm_gen_portaluser';
	protected $primaryKey = 'portaluserid';
	public $timestamps = false;

	/**
	 * Disable remember token from loggin in and logging out
	 *
	 */
	public function getRememberToken() {
		return null; // not supported
	}

	public function setRememberToken($value) {
		// not supported
	}

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = [
		'firstname', 'lastname', 'emailaddress', 'password', 'companyname', 'defaultaddress', 'mobileno', 'currencyid', 'defaultpayment',
		'accounttype', 'dateadded', 'isemailverified', 'accountactive', 'avatarlink', 'isonline', 'loginattemptcntr',
	];

	/**
	 * The attributes that should be hidden for arrays.
	 *
	 * @var array
	 */
	protected $hidden = [
		'password', 'remember_token', 'updated_at',
	];

	public static function getDocuments($portalUserId) {
		return DB::select('call OPC_SelAllCredibilityPerUser(?)', array($portalUserId));
	}

	public function Requests($portalUserID) {
		return DB::select('call OPC_SelBookingTransByPortalUser(?, ?)', array($portalUserID, 'REQUEST'));
	}

	public function Offers($portalUserID) {
		return DB::select('call OPC_SelBookingTransByPortalUser(?, ?)', array($portalUserID, 'OFFER'));
	}
}