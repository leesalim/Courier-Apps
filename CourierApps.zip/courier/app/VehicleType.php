<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehicleType extends Model {
	protected $table = 'gm_gen_vehicletype';
	protected $primaryKey = 'vehicletypeid';

	protected $fillable = [
		'vehicletypecode', 'vehicletypedesc', 'capacity', 'capacityuom', 'vehicleicon',
	];
}
