<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackageType extends Model {
	protected $table = 'gm_gen_packagetype';
	protected $primaryKey = 'packagetypeid';

	protected $fillables = [
		'packagetypecode', 'packagetypedesc', 'packagetypeicon',
	];
}
