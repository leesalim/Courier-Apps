<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class AuthenticateUser {
	public function handle($request, Closure $next, $guard = null) {

		if (Auth::user()) {
			view()->share('currentUser', $user = Auth::user()->emailaddress);
			return $next($request);
		}

		return redirect('/');
	}
}