<?php

namespace App\Http\Controllers;
use App\Booking;
use App\PackageType;
use App\User;
use App\VehicleType;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TransactionController extends Controller {
	public function __construct() {
		$this->middleware('auth.user');
	}

	public function index(Request $request, $type) {
		$user = new User;
		if ($type == 'offers') {
			$offers = $user->Offers(Auth::User()->portaluserid);
			return view('transactions.offers.index', ['offers' => $offers]);
		} else if ($type == 'requests') {
			$requests = $user->Requests(Auth::User()->portaluserid);
			return view('transactions.requests.index', ['requests' => $requests]);
		}
	}

	public function detail(Request $request, $id) {
		$booking = DB::table('opc_gm_bookingtrans')->where('bookingid', $id)->first();
		return view('transactions.detail', ['booking' => $booking]);
	}

	public function home() {
		$offers = DB::select('CALL OPC_SelAllBookingTrans(?, ?, ?, ?, ?);', array(1, null, null, null, 1));
		$requests = DB::select('CALL OPC_SelAllBookingTrans(?, ?, ?, ?, ?);', array(0, null, null, null, 1));
		return view('home', ['offers' => $offers, 'requests' => $requests]);
	}

	public function createOffer() {
		$vehicles = VehicleType::all();
		$packateTypes = PackageType::all();

		return view('transactions.offers.create', array('vehicles' => $vehicles, 'packageTypes' => $packateTypes));
	}

	public function submitOffer(Request $request) {
		$this->validation($request);

		$data = $request->all();
		$data['destcity'] = $data['destinationpoint'];
		$data['pickupcity'] = $data['pickuppoint'];
		$data['isreturntopickup'] = (array_key_exists('isreturntopickup', $data) ? 'Y' : 'N');
		$data['isfragile'] = (array_key_exists('isfragile', $data) ? 'Y' : 'N');
		$data['isbelowroomtemp'] = (array_key_exists('isbelowroomtemp', $data) ? 'Y' : 'N');
		$data['ismaintainroomtemp'] = (array_key_exists('ismaintainroomtemp', $data) ? 'Y' : 'N');
		$data['isperishable'] = (array_key_exists('isperishable', $data) ? 'Y' : 'N');
		$data['portaluserid'] = Auth::user()->portaluserid;
		$data['bookingstatus'] = 'OPEN';
		$data['dateadded'] = date('Y-m-d H:i:s');

		Booking::create($data);
		return redirect('transactions/offers');
	}

	public function createRequest() {
		$vehicles = VehicleType::all();
		$packateTypes = PackageType::all();

		return view('transactions.requests.create', array('vehicles' => $vehicles, 'packageTypes' => $packateTypes));
	}

	public function submitRequest(Request $request) {
		$this->validation($request);

		$data = $request->all();
		$data['destcity'] = $data['destinationpoint'];
		$data['pickupcity'] = $data['pickuppoint'];
		$data['isreturntopickup'] = (array_key_exists('isreturntopickup', $data) ? 'Y' : 'N');
		$data['isfragile'] = (array_key_exists('isfragile', $data) ? 'Y' : 'N');
		$data['isbelowroomtemp'] = (array_key_exists('isbelowroomtemp', $data) ? 'Y' : 'N');
		$data['ismaintainroomtemp'] = (array_key_exists('ismaintainroomtemp', $data) ? 'Y' : 'N');
		$data['isperishable'] = (array_key_exists('isperishable', $data) ? 'Y' : 'N');
		$data['portaluserid'] = Auth::user()->portaluserid;
		$data['bookingstatus'] = 'OPEN';
		$data['dateadded'] = date('Y-m-d H:i:s');

		Booking::create($data);
		return redirect('transactions/requests');
	}

	public function validation($request) {
		return $this->validate($request, [
			'vehicletypeid' => 'required',
			'pickuppoint' => 'required',
			'deliverycharge' => 'required',
			'destinationpoint' => 'required',
			'packagetypeid' => 'required',
		]);
	}
}
