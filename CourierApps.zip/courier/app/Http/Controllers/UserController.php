<?php

namespace App\Http\Controllers;
use App\Credibility;
use App\Currency;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Image;

class UserController extends Controller {
	public function __construct() {
		$this->middleware('auth.user');
	}

	public function profile() {
		$currencies = Currency::all();
		$user = new User();
		$documents = $user->getDocuments(Auth::user()->portaluserid);

		$data = array(
			'user' => Auth::user(),
			'currencies' => $currencies,
			'documents' => $documents,
		);

		return view('profile', $data);
	}

	public function updateAvatar(Request $request) {
		$currencies = Currency::all();
		$documents = User::getDocuments(Auth::user()->portaluserid);

		$user = Auth::user();
		if ($request->hasFile('avatarlink')) {
			$avatar = $request->file('avatarlink');
			$filename = time() . '.' . $avatar->getClientOriginalExtension();
			Image::make($avatar)->resize(300, 300)->save(public_path() . '/uploads/avatars/' . $filename);

			$user->avatarlink = $filename;
		}
		$user->currencyid = $request->currencyid;
		$user->firstname = $request->firstname;
		$user->lastname = $request->lastname;
		$user->companyname = $request->companyname;
		$user->mobileno = $request->mobileno;
		$user->defaultpayment = $request->defaultpayment;
		$user->accounttype = $request->accounttype;
		$user->defaultaddress = $request->defaultaddress;
		$user->save();

		foreach ($documents as $document) {
			if ($request->hasFile($document->documentid)) {
				$uploadedDoc = $request->file($document->documentid);
				$filename = time() . '.' . $uploadedDoc->getClientOriginalExtension();
				Image::make($uploadedDoc)->resize(300, 300)->save(public_path() . '/uploads/documents/' . $filename);

				if ($document->filename != null) {
					$credibility = Credibility::where([
						['documentid', '=', $document->documentid],
						['portaluserid', '=', Auth::user()->portaluserid],
					])->first();

					$document->filename = $filename;

					$credibility->filename = $filename;
					$credibility->dateverified = null;
					$credibility->verifiedby = null;
					$credibility->expirydate = null;
					$credibility->save();
				} else {
					$document->filename = $filename;
					$credibility = new Credibility();
					$credibility->portaluserid = Auth::user()->portaluserid;
					$credibility->filename = $filename;
					$credibility->documentid = $document->documentid;
					$credibility->save();
				}

			}
		}

		$data = array(
			'user' => Auth::user(),
			'currencies' => $currencies,
			'documents' => $documents,
		);

		return view('profile', $data);
	}
}
