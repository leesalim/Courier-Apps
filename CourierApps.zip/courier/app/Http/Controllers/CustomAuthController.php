<?php

namespace App\Http\Controllers;

use App\Currency;
use App\Handlers\Events\UserLoginEvent;
use App\Handlers\Events\UserLoginFailedEvent;
use App\Handlers\Events\UserLogoutEvent;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Laravel\Socialite\Facades\Socialite;
use Mail;

class CustomAuthController extends Controller {

	/**
	 * Redirect the user to the Facebook page.
	 *
	 * @Return Response
	 */
	public function redirectToProvider($socialite) {
		return Socialite::driver($socialite)->redirect();
	}

	public function handleProviderCallback($socialite) {
		$userSocial = Socialite::driver($socialite)->user();

		$findUser = User::where('emailaddress', $userSocial->email)->first();
		if ($findUser) {
			event(new UserLoginEvent($findUser));
			Auth::login($findUser);
		} else {
			$user = new User;
			$user->firstname = $userSocial->name;
			$user->emailaddress = $userSocial->email;
			$user->avatarlink = 'default.jpg';
			$user->dateadded = date('Y-m-d H:i:s');
			$user->lastlogin = date('Y-m-d H:i:s');
			$user->accountactive = 'Y';
			$user->isonline = 1;

			$user->save();
			event(new UserLoginEvent($user));
			Auth::login($user);

		}

		return redirect('/home');
	}

	/*
		* @Description: Registration Form
	*/
	public function showRegisterForm() {
		return view('custom.register');
	}

	public function showUserRegisterForm() {
		$currencies = Currency::all();
		return view('register')->with('currencies', $currencies);
	}

	public function register(Request $request) {
		$this->validation($request);
		$data = $request->all();
		$password = bcrypt($data['password']);
		$data['password'] = $password;
		$data['isemailverified'] = 'N';
		$data['dateadded'] = date('Y-m-d H:i:s');
		$data['accountactive'] = 'Y';

		$user = User::create($data);
		$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

		$url = $protocol . $_SERVER['HTTP_HOST'] . '/verify/v/' . $user->portaluserid . '/t/' . $data['_token'];

		$body = array('name' => $request->firstname . ' ' . $request->lastname, 'link' => $url);

		Mail::send('emails.verify', $body, function ($message) use ($request) {
			$message->from('courier.apps2017@gmail.com', 'Courier Website');
			$message->to($request->emailaddress)->subject('Courier Website Email Verification');
		});

		return redirect('/')->with('Status', 'Your account has been registered successfully, Verify your email first before you login.');
	}

	/**
	 * @Description: Login Form
	 */
	public function showLoginForm() {
		return view('custom.login');
	}

	public function login(Request $request) {
		$this->validate($request, [
			'emailaddress' => 'required|email|max:100',
			'password' => 'required|max:100',
		]);

		$findUser = User::where('emailaddress', $request->emailaddress)->first();
		if (!$findUser) {
			return redirect('/')->with('Status', 'Invalid Account.');
		}

		if ($findUser->loginattemptcnt >= 10) {
			return redirect('/')->with('Status', 'Your account has been locked');
		}

		if (Auth::attempt(['emailaddress' => $request->emailaddress, 'password' => $request->password])) {

			if (is_null(Auth::user()->isemailverified) || Auth::user()->isemailverified == 'N') {
				return redirect('/')->with('Status', 'Please verify your email first.');
			}

			Auth::login(Auth::user());
			event(new UserLoginEvent($findUser));
			return redirect('/home');
		} else {
			event(new UserLoginFailedEvent($findUser));
		}

		return redirect('/')->with('Status', 'Invalid Account.');
	}

	/**
	 * @Description: Validation
	 */
	public function verify($versionId, $tokenId) {
		DB::table('gm_gen_portaluser')
			->where('portaluserid', $versionId)
			->update(['isemailverified' => 'Y']);

		return redirect('/');
	}

	public function forgot(Request $request) {
		$findUser = User::where('emailaddress', $request->emailaddress)->first();
		if ($findUser) {
			$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

			$url = $protocol . $_SERVER['HTTP_HOST'] . '/reset/v/' . $findUser->emailaddress . '/t/' . $request['_token'];

			$body = array('name' => $findUser->firstname . ' ' . $findUser->lastname, 'link' => $url);

			Mail::send('emails.forgot', $body, function ($message) use ($request) {
				$message->from('courier.apps2017@gmail.com', 'Courier Apps');
				$message->to($request->emailaddress)->subject('Forgot Password @ Courier Apps');
			});

			return redirect('/')->with('Status', 'Reset link has been send to your email.');
		}
	}

	public function logout(Request $request) {
		$findUser = User::where('emailaddress', Auth::user()->emailaddress)->first();
		event(new UserLogoutEvent($findUser));
		Auth::logout();

		return redirect('/');
	}

	public function showResetForm($versionId, $tokenId) {
		return view('reset', ['versionId' => $versionId, 'tokenId' => $tokenId]);
	}

	public function reset(Request $request) {
		$this->validate($request, [
			'password' => 'required|confirmed|max:100',
		]);

		DB::table('gm_gen_portaluser')
			->where('emailaddress', $request->emailaddress)
			->update(['password' => bcrypt($request->password)]);

		return view('welcome');
	}

	/**
	 * @Description: Validation
	 */
	public function validation($request) {
		return $this->validate($request, [
			'firstname' => 'required|max:100',
			'lastname' => 'required|max:100',
			'emailaddress' => 'required|email|unique:gm_gen_portaluser|max:100',
			'password' => 'required|confirmed|max:100',
			'accounttype' => 'required',
			'companyname' => 'required|max:100',
			'mobileno' => 'required|max:20',
			'defaultaddress' => 'required',
			'currencyid' => 'required',
			'g-recaptcha-response' => 'required|recaptcha',
		]);
	}
}
