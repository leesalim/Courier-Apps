<?php

namespace App\Http\Controllers;

class RequestsController extends Controller {
	public function __construct() {
		$this->middleware('auth.user');
	}

	public function index() {
		return view('transactions.requests');

	}

	public function create() {

	}
}
