<?php

namespace App\Http\Controllers;

use App\Booking;
use App\PackageType;
use App\VehicleType;
use Auth;
use Illuminate\Http\Request;

class OffersController extends Controller {
	public function __construct() {
		$this->middleware('auth.user');
	}

	public function index() {
		return view('transactions.offers');
	}

	public function create() {
		$vehicles = VehicleType::all();
		$packateTypes = PackageType::all();
		return view('transactions.offers.create', array('vehicles' => $vehicles, 'packageTypes' => $packateTypes));
	}

	public function submit(Request $request) {
		$this->validation($request);
		$data = $request->all();
		$data['isreturntopickup'] = (array_key_exists('isreturntopickup', $data) ? 'Y' : 'N');
		$data['isfragile'] = (array_key_exists('isfragile', $data) ? 'Y' : 'N');
		$data['isbelowroomtemp'] = (array_key_exists('isbelowroomtemp', $data) ? 'Y' : 'N');
		$data['ismaintainroomtemp'] = (array_key_exists('ismaintainroomtemp', $data) ? 'Y' : 'N');
		$data['isperishable'] = (array_key_exists('isperishable', $data) ? 'Y' : 'N');
		$data['portaluserid'] = Auth::user()->portaluserid;
		$data['bookingstatus'] = 'OPEN';
		$data['dateadded'] = date('Y-m-d H:i:s');

		Booking::create($data);
		return view('transactions.offers');
	}

	public function validation($request) {
		return $this->validate($request, [
			'vehicletypeid' => 'required',
			'pickuppoint' => 'required',
			'destinationpoint' => 'required',
			'packagetypeid' => 'required',
		]);
	}
}
