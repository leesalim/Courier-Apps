<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model {
	protected $table = 'opc_gm_bookingtrans';
	protected $primaryKey = 'bookingid';
	public $timestamps = false;

	protected $fillable = [
		'transtype', 'vehicletypeid', 'pickuppoint', 'destinationpoint', 'packagetypeid', 'packagedescription', 'targetdeldatetime', 'additionalnotes', 'pickupdatetime',
		'deliverycharge', 'contactpersondes', 'contactnodes', 'isreturntopickup', 'paymentterms', 'bookingstatus', 'israted', 'isfragile', 'ismaintainroomtemp', 'isbelowroomtemp', 'isperishable', 'portaluserid', 'dateadded', 'bookingstatus', 'pickupcity', 'destcity',
	];
}
