<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Document extends Model {
	protected $table = 'gm_gen_documents';
	protected $primaryKey = 'documentid';

	protected $fillables = [
		'documentid', 'documentdesc', 'points',
	];
}
