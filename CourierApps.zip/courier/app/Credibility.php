<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Credibility extends Model {
	protected $table = 'gm_opc_pucredibility';
	protected $primaryKey = 'creditid';
	public $timestamps = false;

	protected $fillables = [
		'portaluserid', 'documentid', 'filename', 'expirydate', 'nextreminder', 'dateverified', 'verifiedby',
	];
}
