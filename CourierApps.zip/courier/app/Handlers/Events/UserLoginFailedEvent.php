<?php

namespace App\Handlers\Events;
use App\User;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class UserLoginFailedEvent {
	use Dispatchable, InteractsWithSockets, SerializesModels;
	public $User;
	/**
	 * Create a new event instance.
	 *
	 * @return void
	 */
	public function __construct(User $user) {
		$this->user = $user;
	}

}
