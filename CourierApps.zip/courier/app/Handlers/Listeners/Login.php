<?php

namespace App\Handlers\Listeners;

use App\Handlers\Events\UserLoginEvent;
use App\User;

class Login {
	/**
	 * Create the event listener.
	 *
	 * @return void
	 */
	public function __construct() {
		//
	}

	/**
	 * Handle the event.
	 *
	 * @param  UserAuthentication  $event
	 * @return void
	 */
	public function handle(UserLoginEvent $event) {
		$user = $event->user;
		$user->isonline = 1;
		$user->loginattemptcnt += 1;
		$user->update();
	}
}
