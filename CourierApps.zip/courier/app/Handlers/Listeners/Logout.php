<?php

namespace App\Handlers\Listeners;
use App\Handlers\Events\UserLogoutEvent;
use App\User;

class Logout {
	/**
	 * Create the event listener.
	 *
	 * @return void
	 */
	public function __construct(UserLogoutEvent $event) {

	}

	/**
	 * Handle the event.
	 *
	 * @param  UserAuthentication  $event
	 * @return void
	 */
	public function handle(UserLogoutEvent $event) {
		$user = $event->user;
		$user->isonline = 0;
		$user->loginattemptcnt = 0;
		$user->lastlogin = date('Y-m-d H:i:s');
		$user->save();
	}

}
