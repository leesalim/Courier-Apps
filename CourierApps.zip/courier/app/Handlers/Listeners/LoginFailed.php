<?php

namespace App\Handlers\Listeners;

use App\Handlers\Events\UserLoginFailedEvent;

class LoginFailed {
	/**
	 * Create the event listener.
	 *
	 * @return void
	 */
	public function __construct() {
		//
	}

	/**
	 * Handle the event.
	 *
	 * @param  UserAuthentication  $event
	 * @return void
	 */
	public function handle(UserLoginFailedEvent $event) {
		$user = $event->user;
		$user->loginattemptcnt += 1;
		$user->save();
	}
}
