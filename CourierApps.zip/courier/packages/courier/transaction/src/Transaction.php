<?php
namespace Courier\Transaction;

class Transaction {
	public function display() {
		return "This is sample message from Transaction Facade";
	}
}