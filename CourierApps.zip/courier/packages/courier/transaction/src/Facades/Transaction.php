<?php

namespace Courier\Transaction\Facades;

use Illuminate\Support\Facades\Facade;

class Transaction extends Facade {

	protected static function getFacadeAccessor() {
		return 'courier-trasaction';
	}
}