<?php

namespace Courier\Transaction;

use Illuminate\Support\ServiceProvider;

class TransactionServiceProvider extends ServiceProvider {
	public function boot() {
		require __DIR__ . '/routes/routes.php';
	}

	public function register() {
		$this->app->bind('courier-transaction', function(){
			return new Transaction();
		})
	}
}