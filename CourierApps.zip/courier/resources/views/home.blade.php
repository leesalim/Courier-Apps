@extends('layouts.app')

@section('content')
<div class="col-lg-6">
    <div class="panel panel-default">
        <div class="panel-heading"><h4>LATEST DELIVERY REQUESTS</h4></div>

        <div class="panel-body">
            @foreach($requests as $request)
            <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                        <h4><a href="/transactions/detail/{{ $request->bookingid }}">{{ $request->destcity }} - {{ $request->pickupcity }}</a></h4>
                        <div id="colorstar" class="starrr ratable">
                            <span class="glyphicon @if($request->userrating >= 1) glyphicon-star @else glyphicon-star-empty @endif"></span>
                            <span class="glyphicon @if($request->userrating >= 2) glyphicon-star @else glyphicon-star-empty @endif"></span>
                            <span class="glyphicon @if($request->userrating >= 3) glyphicon-star @else glyphicon-star-empty @endif"></span>
                            <span class="glyphicon @if($request->userrating >= 4) glyphicon-star @else glyphicon-star-empty @endif"></span>
                            <span class="glyphicon @if($request->userrating >= 5) glyphicon-star @else glyphicon-star-empty @endif"></span>
                        </div>

                        <small>Posted by: <a href="#">{{ $request->firstname . ' ' . $request->lastname}}</a> on {{ $request->dateadded }}</small>
                    </div>

                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before {{ $request->targetdeldatetime }}</i>
                        <h2>P {{ number_format($request->deliverycharge, 2, '.', ',') }}</h2>
                        <small>Same Day - Meet Up</small>
                    </div>

                    <div class="fb-like" data-href="https://developers.facebook.com/docs/plugins/request{{ $request->bookingid }}" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>

<div class="col-lg-6">
    <div class="panel panel-default">
        <div class="panel-heading"><h4>LATEST DELIVERY OFFERS</h4></div>

        <div class="panel-body">
           @foreach($offers as $offer)
            <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                        <h4><a href="/transactions/detail/{{ $offer->bookingid }}">{{ $offer->destcity }} - {{ $offer->pickupcity }}</a></h4>
                        <div id="colorstar" class="starrr ratable">
                            <span class="glyphicon @if($offer->userrating >= 1) glyphicon-star @else glyphicon-star-empty @endif"></span>
                            <span class="glyphicon @if($offer->userrating >= 2) glyphicon-star @else glyphicon-star-empty @endif"></span>
                            <span class="glyphicon @if($offer->userrating >= 3) glyphicon-star @else glyphicon-star-empty @endif"></span>
                            <span class="glyphicon @if($offer->userrating >= 4) glyphicon-star @else glyphicon-star-empty @endif"></span>
                            <span class="glyphicon @if($offer->userrating >= 5) glyphicon-star @else glyphicon-star-empty @endif"></span>
                        </div>

                        <small>Posted by: <a href="#">{{ $offer->firstname . ' ' . $offer->lastname}}</a> on {{ $offer->dateadded }}</small>
                    </div>

                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before {{ $offer->targetdeldatetime }}</i>
                        <h2>P {{ number_format($offer->deliverycharge, 2, '.', ',') }}</h2>
                        <small></small>
                    </div>


                </div>

                 <div class="fb-like" data-href="https://developers.facebook.com/docs/plugins/offer{{ $offer->bookingid }}" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
            </div>
            @endforeach
        </div>
    </div>
</div>

@endsection
