@extends('layouts.app')

@section('content')
<div class="col-lg-12">
    <div class="panel panel-default">
    <div class="panel-heading"><h4>YOUR REQUESTS <a href="/transactions/requests/create" class="btn btn-xs btn-primary pull-right">Create New</a></h4></div>

        <div class="panel-body">
            @foreach($requests as $request)
             <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                       <h4><a href="/transactions/detail/{{ $request->bookingid }}">{{ ucwords($request->destcity) }} - {{ ucwords($request->pickupcity) }}</a></h4>


                        <small>Posted by: <a href="#">{{ $request->portalusername }}</a> on {{ $request->dateadded }}</small>
                    </div>

                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before {{ $request->targetdeldatetime }}</i>
                        <h2>P {{ number_format($request->deliverycharge, 2, '.', ',') }}</h2>
                        <small>{{$request->pickupdatetime}}</small>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>


@endsection
