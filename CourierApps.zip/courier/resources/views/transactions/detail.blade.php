@extends('layouts.app')

@section('content')
<div class="col-lg-12">
	<div class="panel panel-default">
		<div class="col-xs-12 col-sm-12 col-md-12">
			<h4>Transaction Details</h4>

			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6">
					<div class="form-group">
						<label for="exampleInputEmail1">Transaction Type</label>
						<input type="text" class="form-control" id="exampleInputEmail1" value="{{ $booking->transtype }}">
					</div>

					<div class="form-group">
						<label for="exampleInputEmail1">Destination Point</label>
						<input type="text" class="form-control" value="{{ $booking->destcity }}">
					</div>

					<div class="form-group">
						<label for="exampleInputEmail1">Pickup Point</label>
						<input type="text" class="form-control" value="{{ $booking->pickupcity }}">
					</div>

					<div class="form-group">
						<label for="exampleInputEmail1">Delivery Charge</label>
						<input type="text" class="form-control" value="P {{ number_format($booking->deliverycharge, 2, '.', ',') }}">
					</div>

					<div class="form-group">
						<label for="exampleInputEmail1">Payment Terms</label>
						<input type="text" class="form-control" value="{{ $booking->paymentterms }}">
					</div>
				</div>

				<div class="col-xs-12 col-sm-12 col-md-6">
						<div class="form-group">
							<label for="exampleInputEmail1">Target Delivery Date</label>
							<input type="text" class="form-control" value="{{ $booking->targetdeldatetime }}">
						</div>

						<div class="form-group">
							<label for="exampleInputEmail1">Pickup Date</label>
							<input type="text" class="form-control" value="{{ $booking->pickupdatetime }}">
						</div>

						<div class="form-group">
							<label for="exampleInputEmail1">Contact Person</label>
							<input type="text" class="form-control" value="{{ $booking->contactpersondes }}">
						</div>

						<div class="form-group">
							<label for="exampleInputEmail1">Contact No</label>
							<input type="text" class="form-control" value="{{ $booking->contactpersondes }}">
						</div>
					</div>
			</div>
		</div>

		<div class="fb-comments" data-href="https://developers.facebook.com/docs/plugins/comments#configurator?id={{ $booking->bookingid }}" data-numposts="10"></div>
	</div>
</div>


@endsection
