@extends('layouts.app')

@section('content')
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><h4>OFFER REGISTRY</h4></div>
            <form method="post">
                {{ csrf_field() }}
                <input type="hidden" name="transtype" value="OFFER" />
                <div class="panel-body">
                    <div class="col-xs-12 col-sm-12 col-md-6">
                        <h4>Offer Details</h4>
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <select class="form-control" autofocus="true" tabindex="1" id="vehicletypeid" name="vehicletypeid">
                                      <option disabled selected>Vehicle Type</option>
                                      @foreach($vehicles as $vehicle)
                                        <option
                                            @if( old('vehicletypeid') == $vehicle->vehicletypeid)
                                                selected
                                            @endif
                                            value="{{ $vehicle->vehicletypeid }}">{{ $vehicle->vehicletypedesc }}</option>
                                      @endforeach
                                    </select>
                                    <small class="alert-danger">{{ $errors->first('vehicletypeid') }}</small>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <select class="form-control" tabindex="2" id="paymentterms" name="paymentterms">
                                      <option disabled selected>Payment Terms</option>
                                        @if( old('paymentterms') == 'COD')
                                            <option value="COD" selected>Cash On Delivery</option>
                                        @else
                                            <option value="COD">Cash On Delivery</option>
                                        @endif

                                        @if( old('paymentterms') == 'CREDIT CARD')
                                            <option value="CREDIT CARD" selected>Credit Card</option>
                                        @else
                                            <option value="CREDIT CARD">Credit Card</option>
                                        @endif
                                    </select>
                                    <small class="alert-danger"></small>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <input maxlength="100" type="text" class="form-control"  name="pickuppoint" value="{{ old('pickuppoint') }}" id="pickuppoint" placeholder="Pickup Point" tabindex="3">
                            <small class="alert-danger">{{ $errors->first('pickuppoint') }}</small>
                        </div>

                        <div class="form-group">
                            <input maxlength="100" type="text" class="form-control" name="destinationpoint" value="{{ old('destinationpoint') }}" id="destinationpoint" placeholder="Destination Point" tabindex="4">
                            <small class="alert-danger">{{ $errors->first('destinationpoint') }}</small>
                        </div>

                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <select class="form-control" tabindex="5" id="packagetypeid" name="packagetypeid">
                                      <option disabled selected >Package Type</option>
                                        @foreach($packageTypes as $packageType)
                                            @if( old('packagetypeid') == $packageType->packagetypeid )
                                                <option selected value="{{ $packageType->packagetypeid }}">{{ $packageType->packagetypecode}} - {{ $packageType->packagetypedesc }}</option>
                                            @else
                                                <option value="{{ $packageType->packagetypeid }}">{{ $packageType->packagetypecode}} - {{ $packageType->packagetypedesc }}</option>
                                            @endif
                                        @endforeach
                                  </select>
                                  <small class="alert-danger">{{ $errors->first('packagetypeid') }}</small>
                              </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <input maxlength="100" type="number" class="form-control" value="{{ old('deliverycharge') }}" name="deliverycharge" id="deliverycharge" placeholder="Delivery Charge" tabindex="6">
                                    <small class="alert-danger">{{ $errors->first('deliverycharge') }}</small>
                              </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <input maxlength="100" type="text" class="form-control" value="{{ old('packagedescription') }}" name="packagedescription" id="packagedescription" placeholder="Package Description"  tabindex="7">
                            <small class="alert-danger"></small>
                        </div>

                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <div class="input-group date " tabindex="8" name ="targetdeldatetime" id="targetdeldatetime">
                                        <input type='text' class="form-control timepicker" placeholder="Target Delivery Date" />
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                    <small class="alert-danger">{{ $errors->first('targetdeldatetime') }}</small>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <div class="input-group date" >
                                        <input name ="pickupdatetime" id="pickupdatetime" type='text' class="form-control timepicker" tabindex="9" placeholder="Pickup Date Time" />
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <input maxlength="100" type="text" class="form-control" value="{{ old('additionalnotes') }}" name="additionalnotes" id="additionalnotes" placeholder="Additional Notes" tabindex="10">
                            <small class="alert-danger"></small>
                        </div>

                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <input maxlength="100" type="text" class="form-control" value="{{ old('contactpersondes') }}" name="contactpersondes" id="contactpersondes" placeholder="Contact Person" tabindex="11">
                                    <small class="alert-danger"></small>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <input maxlength="100" type="text" class="form-control" value="{{ old('contactnodes') }}" name="contactnodes" id="contactnodes" placeholder="Contact No" tabindex="12">
                                    <small class="alert-danger"></small>
                                </div>
                            </div>
                        </div>

                        <div class="form-check">
                            <label class="form-check-label">
                              <input type="checkbox" name="isreturntopickup" @if( old('isreturntopickup') == 'on') checked @endif tabindex="13" id="isreturntopickup" class="form-check-input">
                              Return to Pickup Point
                            </label>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-6">
                        <h4>Delivery Conditions</h4>

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" id="isfragile"  @if( old('isfragile') == 'on') checked @endif tabindex="14" name="isfragile" class="form-check-input">
                                      Fragile
                                    </label>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" id="isbelowroomtemp" @if( old('isbelowroomtemp') == 'on') checked @endif tabindex="15" name="isbelowroomtemp" class="form-check-input">
                                      Below Room Temp
                                    </label>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" id="ismaintainroomtemp" @if( old('ismaintainroomtemp') == 'on') checked @endif tabindex="16" name="ismaintainroomtemp" class="form-check-input">
                                      Maintain Room Temp
                                    </label>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-check">
                                    <label class="form-check-label">
                                      <input type="checkbox" id="isperishable" tabindex="17" @if( old('isperishable') == 'on') checked @endif name="isperishable" class="form-check-input">
                                      Perishable
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <br/><br/>
                </div>

                <div class="panel-heading" style="background-color: #f5f5f5; border-color: #ddd;">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <input type="submit" tabindex="18" class="btn btn-primary" value="Save">
                            <a href="/offers" tabindex="19" class="btn btn-primary">Back</a>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </div>

    <script type="text/javascript">
    </script>
@endsection

