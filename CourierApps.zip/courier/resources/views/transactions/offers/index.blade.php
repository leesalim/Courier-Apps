@extends('layouts.app')

@section('content')
<div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading"><h4>YOUR OFFERS <a href="/transactions/offers/create" class="btn btn-xs btn-primary pull-right">Create New</a></h4> </div>

        <div class="panel-body">
            @foreach($offers as $offer)
            <div class="delivery-item">
                <div class="row">
                    <div class="col-lg-6">
                        <h4><a href="/transactions/detail/{{ $offer->bookingid }}">{{ ucwords($offer->destcity) }} - {{ ucwords($offer->pickupcity) }}</a></h4>


                        <small>Posted by: <a href="#">{{ $offer->portalusername }}</a> on {{ $offer->dateadded }}</small>
                    </div>

                    <div class="col-lg-6" style="text-align: right;">
                        <i>Pickup before {{ $offer->targetdeldatetime }}</i>
                        <h2>P {{ number_format($offer->deliverycharge, 2, '.', ',') }}</h2>
                        <small>{{ $offer->pickupdatetime }}</small>
                    </div>
                </div>
            </div>
            @endforeach


        </div>
    </div>
</div>


@endsection
