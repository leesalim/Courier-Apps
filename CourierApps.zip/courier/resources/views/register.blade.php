<html lang="en"><head>
<meta charset="utf-8">
<meta name="robots" content="noindex, nofollow">

<title>Login Screen with Form - Bootsnipp.com</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="//cdn.rawgit.com/twbs/bootstrap/v4-dev/dist/css/bootstrap.css" rel="stylesheet" id="bootstrap-css">
<style type="text/css">
    @import url("//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css");

/*
The above link can also go in HTML document as a link in head.
Rather than @import in an external CSS file,
The following code into the <head> section of your site's HTML.
<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
*/


/*
 * Social Buttons for Bootstrap
 *
 * Copyright 2013-2014 Panayiotis Lipiridis
 * Licensed under the MIT License
 *
 * https://github.com/lipis/bootstrap-social
 */


    .login-block{
        background: #DE6262;  /* fallback for old browsers */
        background: -webkit-linear-gradient(to bottom, #007bb6, #fff);  /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to bottom, #007bb6, #fff); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        float:left;
        width:100%;
        padding : 50px 0;
        height: 100%;
    }
    .banner-sec{max-height: 70%; background-size:cover; min-height:500px; border-radius: 10px 0 0 10px; padding:0; }
    .container{background:#fff; border-radius: 10px; box-shadow:15px 20px 0px rgba(0,0,0,0.1); max-width: 600px !important;}
    .carousel-inner{border-radius: 10px 0 0 10px;}
    .carousel-caption{text-align:left; left:5%;}
    .img-fluid {height: 100%;}
    .login-sec{padding: 50px 30px; position:relative;}
    .login-sec .copy-text{position:absolute; width:80%; bottom:20px; font-size:13px; text-align:center;}
    .login-sec .copy-text i{color:#FEB58A;}
    .login-sec .copy-text a{color:#E36262;}
    .login-sec h2{margin-bottom:30px; font-weight:800; font-size:30px; color: #007bb6;}
    .login-sec h2:after{content:" "; width:100px; height:5px; background: #007bb6; display:block; margin-top:20px; border-radius:3px; margin-left:auto;margin-right:auto}
    .btn-login{background: #DE6262; color:#fff; font-weight:600;}
    .banner-text{width:70%; position:absolute; bottom:40px; padding-left:20px;}
    .banner-text h2{color:#fff; font-weight:600;}
    .banner-text h2:after{content:" "; width:100px; height:5px; background:#FFF; display:block; margin-top:20px; border-radius:3px;}
    .banner-text p{color:#fff;}

    .bg-primary {
        background: #DE6262;  /* fallback for old browsers */
        background: -webkit-linear-gradient(to bottom, #fff, #007bb6);  /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to bottom, #fff, #007bb6); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera */
     }

     .btn {
        margin: 5px 5px 0 0;
     }



     .colorgraph {
  height: 5px;
  border-top: 0;
  background: #c4e17f;
  border-radius: 5px;
  background-image: -webkit-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: -moz-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: -o-linear-gradient(left, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
  background-image: linear-gradient(to right, #c4e17f, #c4e17f 12.5%, #f7fdca 12.5%, #f7fdca 25%, #fecf71 25%, #fecf71 37.5%, #f0776c 37.5%, #f0776c 50%, #db9dbe 50%, #db9dbe 62.5%, #c49cde 62.5%, #c49cde 75%, #669ae1 75%, #669ae1 87.5%, #62c2e4 87.5%, #62c2e4);
}

</style>

<script type="text/javascript">
    window.alert = function(){};
    var defaultCSS = document.getElementById('bootstrap-css');
    function changeCSS(css){
        if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />');
        else $('head > link').filter(':first').replaceWith(defaultCSS);
    }
    $( document ).ready(function() {
      var iframe_height = parseInt($('html').height());
      window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
  });
</script>
</head>
<body style="">

     <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#"><b>Courier Apps</b></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto"></ul>
            <a href="#" class="btn btn-outline-primary my-2 my-sm-0" >HOME</a>
            <a href="#" class="btn btn-outline-primary my-2 my-sm-0">HOW IT HELPS</a>
            <a href="#" class="btn btn-outline-primary my-2 my-sm-0">HOW IT WORKS</a>
            <a href="#" class="btn btn-outline-primary my-2 my-sm-0">TESTIMONALS</a>
      </div>
    </nav>

    <section class="login-block">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-offset-2 col-md-offset-3 login-sec">
                    <form  method="post">
                        {{csrf_field()}}
                        <h2>Please Sign Up <small>It's free and always will be.</small></h2>
                        <hr class="colorgraph">

                        <div class="form-group">
                        <select class="form-control" tabindex="6" id="accounttype" name="accounttype">
                              <option disabled selected>Account Type</option>
                              @if( old('accounttype') == 'PERSONAL')
                                <option value="PERSONAL" selected>PERSONAL</option>
                              @else
                                <option value="PERSONAL">PERSONAL</option>
                              @endif

                              @if( old('accounttype') == 'COMPANY')
                                <option value="COMPANY" selected>COMPANY</option>
                              @else
                                <option value="COMPANY">COMPANY</option>
                              @endif
                          </select>
                           <small class="alert-danger">{{ $errors->first('accounttype') }}</small>
                      </div>

                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <input maxlength="100" type="text" class="form-control" value="{{old('firstname')}}" name="firstname" id="firstname" placeholder="First Name" autofocus="true" tabindex="1">
                            <small class="alert-danger">{{ $errors->first('firstname') }}</small>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" tabindex="2" value="{{old('lastname')}}" name="lastname" id="lastname" placeholder="Last Name">
                            <small class="alert-danger">{{ $errors->first('lastname') }}</small>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <input maxlength="100" type="text" tabindex="3" class="form-control" value="{{old('companyname')}}" name="companyname" id="companyname" placeholder="Company Name">
                            <small class="alert-danger">{{ $errors->first('companyname') }}</small>
                        </div>

                        <div class="form-group">
                            <input maxlength="255" type="text" tabindex="4" class="form-control" value="{{old('defaultaddress')}}" name="defaultaddress" id="defaultaddress" placeholder="Address">
                             <small class="alert-danger">{{ $errors->first('defaultaddress') }}</small>
                        </div>


                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <input maxlength="20" type="text" tabindex="5" placeholder="Mobile No" class="form-control" value="{{old('mobileno')}}" name="mobileno" id="mobileno" >
                                    <small class="alert-danger">{{ $errors->first('mobileno') }}</small>
                                </div>

                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <select class="form-control" tabindex="6" id="currencyid" name="currencyid">
                                      <option disabled selected>Currency</option>
                                      @foreach($currencies as $currency)
                                        @if( old('currencyid') == $currency->currencyid )
                                            <option value="{{ $currency->currencyid }}" selected>{{ $currency->currencydesc }}</option>
                                        @else
                                            <option value="{{ $currency->currencyid }}">{{ $currency->currencydesc }}</option>
                                        @endif
                                      @endforeach
                                  </select>
                                   <small class="alert-danger">{{ $errors->first('currencyid') }}</small>
                              </div>
                          </div>
                      </div>

                        <div class="form-group">
                            <input maxlength="100" type="email" tabindex="7" name="emailaddress" id="emailaddress" class="form-control input-lg" placeholder="Email Address" tabindex="4"
                            value="{{ old('emailaddress') }}">
                             <small class="alert-danger">{{ $errors->first('emailaddress') }}</small>
                        </div>

                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <input maxlength="100" tabindex="8" type="password" class="form-control" name="password" id="password" placeholder="Password">
                            <small class="alert-danger">{{ $errors->first('password') }}</small>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <input maxlength="100" tabindex="9" type="password" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Re-Password">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            {!! Recaptcha::render() !!}
                            <small class="alert-danger">{{ $errors->first('g-recaptcha-response') }}</small>
                        </div>

                        <hr class="colorgraph">
                        <div class="row">
                            <div class="col-xs-12 col-md-6"><input tabindex="10" type="submit" value="Register" class="btn btn-primary btn-block btn-lg" tabindex="7"></div>
                            <div class="col-xs-12 col-md-6">
                                <a href="/" tabindex="11" class="btn btn-success btn-block btn-lg">Sign In</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>

        <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
        <script src="//cdn.rawgit.com/twbs/bootstrap/v4-dev/dist/js/bootstrap.js"></script>
        <script type="text/javascript">

        </script>

    </body>
</html>