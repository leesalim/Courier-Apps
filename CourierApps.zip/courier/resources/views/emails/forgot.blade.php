Hi <b>{{$name}}</b>,

<p>Click the link given below to reset your registration.</p>
<br/>
&nbsp;&nbsp;&nbsp; <a href="{{ $link }}">{{ $link }}</a>