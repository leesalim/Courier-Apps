Hi <b>{{$name}}</b>,

<p>Click the link given below to complete your registration.</p>
<br/>
&nbsp;&nbsp;&nbsp; <a href="{{ $link }}">{{ $link }}</a>